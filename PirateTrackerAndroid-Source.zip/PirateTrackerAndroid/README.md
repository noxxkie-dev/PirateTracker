# Pirate Tracker Android

An unofficial, offline Fortnite companion tracker. It does not connect to Fortnite or read game memory.

## Features
- Pirate-themed dashboard and event tracking start/stop
- Locally saved chest markers and opened/token-found history
- Cannon marker list
- 0–100 personal map grid with manually entered pins
- Nearest unopened chest suggestion based on your manually updated position
- Data stored locally in the app's WebView local storage

## Important limitations
- No in-game teleportation, ESP/wallhack, game-memory access, automation, or anti-cheat bypass.
- Cannon/chest pins are user-entered, not verified official Fortnite locations.
- The grid is a personal planning board, not an accurate Fortnite map or live player location feed.

## Build an APK using GitHub from your Android phone
1. Create a GitHub account if needed.
2. Create a new repository named `PirateTracker`.
3. Upload the contents of this project (not the outer ZIP folder) to the repository.
4. Open the repository's **Actions** tab and run **Build Pirate Tracker APK** (or wait for the first push build).
5. Open the completed workflow run, scroll to **Artifacts**, and download `PirateTracker-debug-apk`.
6. Extract the downloaded artifact ZIP. Install `app-debug.apk` on your Android phone. Android may ask you to allow installs from your browser/file manager.

The APK is a debug build for personal testing. A Play Store release would need a signed release build.
